Name: Connor Michetti
To compile my lab, just type make. To run the compiled program, type ./mysh
